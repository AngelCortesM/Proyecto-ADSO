package com.hybridbusinesssolutions.angel;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.hybridbusinesssolutions.angel.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding binding;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        databaseHelper = new DatabaseHelper((this));

        binding.btnLogin.setOnClickListener(v -> {
            String username = binding.editTextnamelogin.getText().toString();
            String password = binding.editTextPasswordlogin.getText().toString();

            if (username.equals("") || password.equals("")){
                Toast.makeText(MainActivity.this,"Los campos son obligatoris =) ", Toast.LENGTH_SHORT).show();
            }else {
                Boolean verificarcontrasena = databaseHelper.verificarContrasena(username,password);

                if(verificarcontrasena == true){
                    Toast.makeText(MainActivity.this,"Ud ingreso de manera correcta", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(),Home.class);
                    startActivity(intent);
                }else {
                    Toast.makeText(MainActivity.this, "Usuario o contraseña incorrecta", Toast.LENGTH_SHORT).show();
                }
            }
        });
        binding.btnSingUp.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this,registro_user.class);
            startActivity(intent);
        });
    }

}