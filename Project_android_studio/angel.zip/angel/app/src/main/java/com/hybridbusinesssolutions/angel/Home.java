package com.hybridbusinesssolutions.angel;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
public class Home extends AppCompatActivity {

    DatabaseHelper databaseHelper;
    ListView listadousuarios;
    ArrayList<String> listItem;
    ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_home);

        databaseHelper = new DatabaseHelper(this);
        listItem = new ArrayList<>();

        listadousuarios = findViewById(R.id.listadousuarios);
        recorrerDatos();

        Button btnRegistroItem = findViewById(R.id.btnRegistroItem);
        Button btnRegistroProveedor = findViewById(R.id.btnRegistroProveedor);
        btnRegistroItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Lanza la actividad RegistroItemActivity
                Intent intent = new Intent(Home.this, registro_item.class);
                startActivity(intent);
            }
        });
        btnRegistroProveedor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Lanza la actividad RegistroProveedorActivity
                Intent intent = new Intent(Home.this, registro_proveedores.class);
                startActivity(intent);
            }
        });

    }

    private void recorrerDatos(){
        Cursor cursor = databaseHelper.consultarUsuarios();
        if (cursor.getCount() == 0){
            Toast.makeText(Home.this,"No se encontraron datos",Toast.LENGTH_SHORT).show();
        }else {
            while (cursor.moveToNext()){
                listItem.add(cursor.getString(1));
            }
                adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listItem);
            listadousuarios.setAdapter(adapter);
        }
    }
}