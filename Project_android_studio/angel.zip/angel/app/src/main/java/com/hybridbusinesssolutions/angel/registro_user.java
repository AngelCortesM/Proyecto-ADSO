package com.hybridbusinesssolutions.angel;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.hybridbusinesssolutions.angel.databinding.ActivityRegistroUserBinding;

public class registro_user extends AppCompatActivity {
    ActivityRegistroUserBinding binding;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRegistroUserBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        databaseHelper = new DatabaseHelper(this);

        binding.btnRegistro.setOnClickListener(v -> {

            String nombrecompleto = binding.editTextname.getText().toString();
            String username = binding.editTextuser.getText().toString();
            String password = binding.editTextPassword.getText().toString();
            String passwordc = binding.editTextpasswordc.getText().toString();
            if (nombrecompleto.equals("") || username.equals("") || password.equals("") || passwordc.equals("")){
                Toast.makeText(registro_user.this,"Todos los Campos son obligatorios", Toast.LENGTH_SHORT).show();
            }
            else {
                if (password.equals(passwordc)){
                    Boolean verificarusuario = databaseHelper.verificarUsername(username);

                    if (verificarusuario == false){
                        Boolean insertar = databaseHelper.insertarDatos(username, nombrecompleto, password);
                        if (insertar == true){
                            Toast.makeText(registro_user.this,"Usuario guardado con éxito", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                            startActivity(intent);
                        }else {
                            Toast.makeText(registro_user.this,"Hubo un error al guardar el usuario "+ username +" ", Toast.LENGTH_SHORT).show();
                        }
                    }else {
                        Toast.makeText(registro_user.this,"El usuario "+ username +" ya existe, elija uno nuevo", Toast.LENGTH_SHORT).show();

                    }
                }
            }
        });
        binding.btnVolver1.setOnClickListener(v -> {
            Intent intent = new Intent(registro_user.this,MainActivity.class);
            startActivity(intent);
        });
    }
}